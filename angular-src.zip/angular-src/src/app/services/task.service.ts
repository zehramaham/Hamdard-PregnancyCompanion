import { Injectable } from '@angular/core';
import {HttpClientModule} from '@angular/common/http'
import {HttpClient} from '@angular/common/http'
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private http:HttpClient) {
    console.log("Service initialized..")

   }

   getTask(){
     console.log("Hello")
     return this.http.get<any>('http://localhost:3000/users/note')
   }

   addTask(newTask){
    console.log("this is the new task",newTask)
    return this.http.post<any>('http://localhost:3000/users/note',newTask)
   }
   

   deleteTask(id){
     console.log(id);
    return this.http.delete<any>('http://localhost:3000/users/note/'+id)
}
  updateStatus(task){
    console.log("task service", task)
    return this.http.put<any>('http://localhost:3000/users/note/'+task._id, task)
  }
  getAppointment(){
    console.log("Hello")
    return this.http.get<any>('http://localhost:3000/users/appointment')
  }

  addAppointment(newTask){
   console.log("this is the new task",newTask)
   return this.http.post<any>('http://localhost:3000/users/appointment',newTask)
  }
  

  deleteAppointment(id){
    console.log(id);
   return this.http.delete<any>('http://localhost:3000/users/appointment/'+id)
}
 updateAppointment(task){
   console.log("task service", task)
   return this.http.put<any>('http://localhost:3000/users/appointment/'+task._id, task)
 }

 getMood(){
  console.log("Hello")
  return this.http.get<any>('http://localhost:3000/users/mood')
}

addMood(newTask){
 console.log("this is the new task",newTask)
 return this.http.post<any>('http://localhost:3000/users/mood',newTask)
}


deleteMood(id){
  console.log(id);
 return this.http.delete<any>('http://localhost:3000/users/mood/'+id)
}
updateMood(task){
 console.log("task service", task)
 return this.http.put<any>('http://localhost:3000/users/mood/'+task._id, task)
}
   
}
