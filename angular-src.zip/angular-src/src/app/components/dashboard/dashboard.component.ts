import { Task } from './../../../../../models/Task';
import { TaskService } from './../../services/task.service';
import { AuthService } from './../../services/auth.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  tasks: Task[]
  task_name: string
  task_info: string
  task_userId: string
  editState: boolean = false;
  taskToEdit: Task;

  
  constructor(private taskService:TaskService, private authService:AuthService) {
    this.taskService.getTask().subscribe(tasks=>{this.tasks=tasks});
   }

  ngOnInit(): void {
    this.authService.getProfile().subscribe(profile => {
      // this.user = profile['user'];
      this.task_userId=profile['user']._id
    },
     err => {
       console.log(err);
       return false;
     });
  
  }

  addTask(event){
    event.preventDefault();
    console.log(this.task_name);
    console.log(this.task_userId);
    var newTask={
      task_userId: this.task_userId,
      task_name: this.task_name,
      task_info: this.task_info
    }
    this.taskService.addTask(newTask)
    .subscribe(task=> {
      this.tasks.push(task)
      this.task_info='';
      this.task_name ='';
  })
 }

 deleteTask(id){
   this.clearState();
  var tasks = this.tasks;
  
  this.taskService.deleteTask(id).subscribe(data => {
      if(data.n == 1){
          for(var i = 0;i < tasks.length;i++){
              if(tasks[i]._id == id){
                  tasks.splice(i, 1);
              }
          }
      }
  });
}

editTask(event, task: Task){
  this.editState = true;
  this.taskToEdit = task;
}

updateStatus(task){
  console.log(task)
  var _task = {
      _id:task._id,
      task_userId: task.userId,
      task_name: task.task_name,
      task_info: task.task_info
  };
  
  this.taskService.updateStatus(_task).subscribe(data => {
      task.task_name = _task.task_name;
      task.task_info = _task.task_info;  
  });
  this.clearState()
}
clearState(){
  this.editState = false;
  this.taskToEdit = null;
}

}
