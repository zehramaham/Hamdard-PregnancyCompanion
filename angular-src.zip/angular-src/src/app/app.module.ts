import { TaskService } from './services/task.service';
import { AuthGuard } from './guards/auth.guard';
import { AuthService } from './services/auth.service';
import { ValidateService } from './services/validate.service';
import { JwtHelperService, JWT_OPTIONS, JwtModule } from '@auth0/angular-jwt';
import { RouterModule, Routes } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { HomeComponent } from './components/home/home.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ProfileComponent } from './components/profile/profile.component';
import { FlashMessagesModule } from 'angular2-flash-messages';
import { HttpClientModule } from '@angular/common/http';
import { WeightTrackComponent } from './components/weight-track/weight-track.component';
import { AppointmentComponent } from './components/appointment/appointment.component';
import { MoodComponent } from './components/mood/mood.component';
import { NoteComponent } from './components/note/note.component';
import { MatSliderModule } from '@angular/material/slider';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';



const appRoutes: Routes = [
  {path:"", component: HomeComponent },
  {path:'register', component: RegisterComponent},
  {path:'login', component: LoginComponent},
  {path:'dashboard', component: DashboardComponent, canActivate: [AuthGuard]},
  {path:'profile', component: ProfileComponent, canActivate: [AuthGuard]},
  {path: 'note', component: NoteComponent, canActivate: [AuthGuard]},
  {path: 'appointment', component: AppointmentComponent, canActivate: [AuthGuard]},
  {path: 'mood', component: MoodComponent, canActivate: [AuthGuard]}
  
]

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    DashboardComponent,
    ProfileComponent,
    WeightTrackComponent,
    AppointmentComponent,
    MoodComponent,
    NoteComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    FormsModule,
    RouterModule.forRoot(appRoutes),
    FlashMessagesModule.forRoot(),
    HttpClientModule,
    NoopAnimationsModule,
    MatSliderModule
    ],
  providers: [ValidateService, AuthService, { provide: JWT_OPTIONS, useValue: JWT_OPTIONS },
    JwtHelperService, AuthGuard, TaskService],
  bootstrap: [AppComponent]
})
export class AppModule { }
